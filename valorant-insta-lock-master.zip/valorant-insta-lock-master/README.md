# valorant-insta-lock
This script instant locks characters in the game Valorant.


First run setup.py and setup your character order. Next run the agent_select.py to select the agent you wanna play. Then run the instalocker.py before you want to play Valorant. Then wait for agent selet and simply press F6 fast. If it wont work, you may have to press it multiple times. Its an issue of valorant. 
 

If there are any questions or bugs, let me know! 

PS: 
I'm working on a GUI for all that setup stuff. That's coming soon.
